suppressPackageStartupMessages(library(ahriTRErRs))
if (file.exists('.env')) readRenviron('.env')

runtime_candidates <- unique(c(Sys.getenv('AHRI_TRE_RUNTIME_ROOT', '/opt/ahri-tre-runtime'), file.path(getwd(), '.runtime', 'ahri-tre-runtime'), '/workspaces/ahriTRErRs/.runtime/ahri-tre-runtime'))
runtime_roots <- normalizePath(path.expand(runtime_candidates), mustWork = FALSE)
runtime_manifests <- file.path(runtime_roots, 'share', 'ahri-tre', 'manifest.json')
runtime_hits <- runtime_roots[file.exists(runtime_manifests)]
runtime_root <- if (length(runtime_hits) > 0L) runtime_hits[[1]] else runtime_roots[[1]]
manifest <- file.path(runtime_root, 'share', 'ahri-tre', 'manifest.json')
Sys.setenv(AHRI_TRE_RUNTIME_ROOT = runtime_root)
cat('[INFO] AHRI_TRE_RUNTIME_ROOT=', runtime_root, '\n', sep = '')

if (!file.exists(manifest)) {
  cat('[WARN] Runtime manifest not found at ', manifest, '\n', sep = '')
  cat('[INFO] Install runtime and rerun this example.\n')
  quit(save = 'no', status = 0L)
}

study_name <- "Rfam_Database_Collection"
domain_name <- Sys.getenv('AHRI_TRE_DOMAIN', 'Basic_Science')
mysql_database <- Sys.getenv('AHRI_TRE_MYSQL_DATABASE', Sys.getenv('AHRI_TRE_MYSQL_SCHEMA', Sys.getenv('MYSQL_DB', '')))
targets <- c('family', 'clan', 'taxinomy', 'clan_membership', 'full_region', 'rfamseq')
mysql_host <- Sys.getenv('AHRI_TRE_MYSQL_HOST', Sys.getenv('MYSQL_Host', ''))
mysql_port <- Sys.getenv('AHRI_TRE_MYSQL_PORT', Sys.getenv('MYSQL_PORT', ''))
mysql_user <- Sys.getenv('AHRI_TRE_MYSQL_USER', Sys.getenv('MYSQL_User', ''))
mysql_password_env <- Sys.getenv('AHRI_TRE_MYSQL_PASSWORD_ENV', '')
mysql_password <- Sys.getenv('AHRI_TRE_MYSQL_PASSWORD', Sys.getenv('MYSQL_Password', ''))
if (!nzchar(mysql_password_env)) {
  mysql_password_env <- 'MYSQL_Password'
}
if (!nzchar(mysql_password)) mysql_password <- Sys.getenv(mysql_password_env, '')
if (!nzchar(domain_name) || !nzchar(mysql_host) || !nzchar(mysql_user) || !nzchar(mysql_database)) {
  cat('[INFO] Set AHRI_TRE_DOMAIN, AHRI_TRE_MYSQL_HOST, AHRI_TRE_MYSQL_USER, and AHRI_TRE_MYSQL_DATABASE to run MySQL ingest. Skipping.\n')
  quit(save = 'no', status = 0L)
}
if (!nzchar(mysql_password)) {
  cat('[INFO] MySQL password is empty; proceeding with empty password from environment configuration.\n')
}

client <- AhriTreClient()
on.exit(close(client), add = TRUE)

any_failed <- FALSE

for (dataset_name in targets) {
  table_var <- paste0('AHRI_TRE_MYSQL_TABLE_', toupper(dataset_name))
  table_name <- Sys.getenv(table_var, if (identical(dataset_name, 'taxinomy')) 'taxonomy' else dataset_name)
  if (nzchar(mysql_database)) {
    source_ref <- paste0(mysql_database, '.', table_name)
  } else {
    source_ref <- table_name
  }
  sql_text <- paste0('select * from ', source_ref)
  description_value <- paste0('mysql_select_all_', dataset_name)

  cat('[INFO] Ingesting dataset ', dataset_name, ' from ', source_ref, '\n', sep = '')
  res <- ingest_dataset_sql(
    client,
    study = study_name,
    format = 'json',
    domain = domain_name,
    dataset = dataset_name,
    sql = sql_text,
    flavour = 'mysql',
    description = description_value,
    source_host = mysql_host,
    source_port = if (nzchar(mysql_port)) mysql_port else NULL,
    source_user = mysql_user,
    source_password_env = mysql_password_env,
    source_db = mysql_database
  )

  status_value <- if (!is.null(res$envelope$status) && nzchar(as.character(res$envelope$status[[1]]))) as.character(res$envelope$status[[1]]) else 'ok'
  cat('[INFO] ingest_dataset_sql status (', dataset_name, '): ', status_value, '\n', sep = '')
  print(res$data)
}
