#!/usr/bin/env Rscript
#
# Ingest a dataset from a SQL query (MSSQL flavour).
#
# Environment variables:
#   AHRI_TRE_STUDY          - Study name
#   AHRI_TRE_DOMAIN         - Domain name
#   AHRI_TRE_DATASET        - Dataset name
#   AHRI_TRE_SQL            - SQL query string
#   AHRI_TRE_RUNTIME_ROOT   - Runtime root (auto-discovered)

suppressPackageStartupMessages(library(ahriTRErRs))

resolve_runtime_root <- function() {
  candidates <- unique(c(
    Sys.getenv("AHRI_TRE_RUNTIME_ROOT", "/opt/ahri-tre-runtime"),
    file.path(getwd(), ".runtime", "ahri-tre-runtime"),
    "/workspaces/ahriTRErRs/.runtime/ahri-tre-runtime"
  ))
  roots <- normalizePath(path.expand(candidates), mustWork = FALSE)
  manifests <- file.path(roots, "share", "ahri-tre", "manifest.json")
  hits <- roots[file.exists(manifests)]
  if (length(hits) > 0L) hits[[1]] else roots[[1]]
}

if (file.exists(".env")) readRenviron(".env")

study_name <- Sys.getenv("AHRI_TRE_STUDY", "")
domain_name <- Sys.getenv("AHRI_TRE_DOMAIN", "")
dataset_name <- Sys.getenv("AHRI_TRE_DATASET", "")
sql_text <- Sys.getenv("AHRI_TRE_SQL", "")

if (!nzchar(study_name) || !nzchar(domain_name) || !nzchar(dataset_name) || !nzchar(sql_text)) {
  cat("[INFO] Set AHRI_TRE_STUDY, AHRI_TRE_DOMAIN, AHRI_TRE_DATASET, AHRI_TRE_SQL to run SQL ingest. Skipping.\n")
  quit(save = "no", status = 0L)
}

runtime_root <- resolve_runtime_root()
Sys.setenv(AHRI_TRE_RUNTIME_ROOT = runtime_root)

client <- AhriTreClient()
on.exit(close(client), add = TRUE)

res <- try_tre(
  ingest_dataset_sql(
    client,
    study = study_name,
    domain = domain_name,
    dataset = dataset_name,
    sql = sql_text,
    flavour = "mssql",
    format = "json"
  ),
  context = "MSSQL ingest"
)

status_value <- if (!is.null(res$envelope$status) && nzchar(as.character(res$envelope$status[[1]]))) {
  as.character(res$envelope$status[[1]])
} else {
  "ok"
}
cat(sprintf("[INFO] ingest_dataset_sql status: %s\n", status_value))
print(res$data)